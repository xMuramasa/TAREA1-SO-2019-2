### TAREA2-SO-2019-2 ~2020~
# Repositorio de la Tarea 2 de Sistemas Operativos

			(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧ ✧ﾟ･: *ヽ(◕ヮ◕ヽ) (ﾉ◕ヮ◕)ﾉ*:･ﾟ✧ ✧ﾟ･: *ヽ(◕ヮ◕ヽ)


# Entrega 1 en proceso
# Integrantes:
	
	- Nombre: ROL
	- Zhuo Chang 201773617-8 
	- Martín Salinas Scussolin 201773557-0

			
			(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧ ✧ﾟ･: *ヽ(◕ヮ◕ヽ)(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧ ✧ﾟ･: *ヽ(◕ヮ◕ヽ)
					(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧ ✧ﾟ･: *ヽ(◕ヮ◕ヽ)


# Instrucciones de uso:
	
	** para correr el programa en una linea (make clean && make && make run)
   #### Entrega 1:
		* Para probar funciones, editar el archivo main.c
		* Se compila usando make, dentro de la carpeta src (escribir en la consola: make)
		luego, ejecutar usando el comando: make run.
			*** Por consola se solicitará input indicando la parte de la tarea que se desea ejecutar
				(Esta pensado para funcionar bien)
			*** Despues de haber seleccionado una de las opciones, correra dicha eleccion, para posteriormente
			    correr la opcion que no se indico una vez terminada  la ejecucion de la primera

					

						(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧ ✧ﾟ･: *ヽ(◕ヮ◕ヽ)
	

			(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧ ✧ﾟ･: *ヽ(◕ヮ◕ヽ)(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧ ✧ﾟ･: *ヽ(◕ヮ◕ヽ)


# Responsabilidades de lo que se hizo (entrega 1):
	
	- Zhuo Chang: 
	- Martín Salinas Scussolin: 
